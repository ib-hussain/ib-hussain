#include <semaphore.h>
#include <mutex>
#include <thread>
#include <chrono>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/wait.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <iostream>
#include <string>
#include <cstring>
#include <errno.h>
#include <sys/types.h>
using namespace std;


int main(int argc, char* argv[]){
    int Nanana;
    if(argc>1){ Nanana = (stoi(argv[1])>0?stoi(argv[1]):-67); if(Nanana==-67)exit(-2);}else{exit(-1);}
    // cout<<"we survived\n";
    pid_t workers[Nanana];

    for(int abcd=0;abcd<Nanana;abcd++){
        workers[abcd]=fork();
        if(workers[abcd]==0){

        }else if (workers[abcd]>0){

        }else{

        }
    }

return 0;
}



