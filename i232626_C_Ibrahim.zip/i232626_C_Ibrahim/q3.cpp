#include <semaphore.h>
#include <mutex>
#include <thread>
#include <chrono>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/wait.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <iostream>
#include <string>
#include <cstring>
#include <errno.h>
#include <sys/types.h>
using namespace std;


int main(int argc, char* argv[]){
    int fd[2];
    // cout<<"we survived\n";
    // pid_t workers[Nanana];
    pid_t once=fork();
    if(pipe(fd)<0)exit(-2);

    if(once==0){
        close(fd[1]);
        char* num[1024];
        read(fd[0], num, 1023);
        cout<<" this is the recieved number : "<<num<<endl;
        exit(0);

    }else if (once>0){
        close(0);
        cout<<"Please enter a number: ";char* number;cin>> number;
        write(fd[1], number, sizeof(number));
        wait(NULL);
    }else{
        cout<<"error in fork \n";
    }

return 0;
}



