#include <semaphore.h>
#include <mutex>
#include <thread>
#include <chrono>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/wait.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <iostream>
#include <string>
#include <cstring>
#include <errno.h>
#include <sys/types.h>
using namespace std;

#define CpuResource 2
#define MemoryResource 3 // cuz if everyone uses 2 and total is 6 then 3 is also satisfactory unless there was another process that was to enter and used odd number of memory resources
#define ReactionTime 200

sem_t GotCPU;
sem_t GotMemory;
sem_t TaskGo;

void selfKill(){cout<<"I am going to kill myself :) cuz i avctually did everything\n";kill(getpid(), SIGKILL);}
unsigned long long int RandRand(long long int abc){abc = abc*23/67%46*(getpid())%31*3.1415926*abc*48659; return (abc>0?abc:(abc*-1));}
void* Analyst1(void*){
    int tasksDone =0;
    int analystNum =1;
    while(tasksDone<10){
        cout<<"It is Analyst "<<analystNum<<" speaking and we are about to start a task\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_wait(&GotMemory);
        cout<<"It is Analyst "<<analystNum<<" speaking and we have got 2 memory slots\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_wait(&GotCPU);
        cout<<"It is Analyst "<<analystNum<<" speaking and we have got a CPU FINALYYYYY\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_wait(&TaskGo);
        cout<<"It is Analyst "<<analystNum<<" speaking and we are about to start task number "<<tasksDone <<"\n";
        this_thread::sleep_for(chrono::milliseconds(300));tasksDone+=1;
        cout<<"It is Analyst "<<analystNum<<" speaking and we have completed task number "<<tasksDone <<"\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_post(&GotCPU);
        cout<<"It is Analyst "<<analystNum<<" speaking and we released the cpu from the shackles\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_post(&TaskGo);
        sem_post(&GotMemory);
        cout<<"It is Analyst "<<analystNum<<" speaking and we released the memory from the shackles\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
    }
}
void* Analyst2(void*){
    int tasksDone =0;
    int analystNum =2;
    while(tasksDone<10){
        cout<<"It is Analyst "<<analystNum<<" speaking and we are about to start a task\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_wait(&GotMemory);
        cout<<"It is Analyst "<<analystNum<<" speaking and we have got 2 memory slots\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_wait(&GotCPU);
        cout<<"It is Analyst "<<analystNum<<" speaking and we have got a CPU FINALYYYYY\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_wait(&TaskGo);
        cout<<"It is Analyst "<<analystNum<<" speaking and we are about to start task number "<<tasksDone <<"\n";
        this_thread::sleep_for(chrono::milliseconds(300));tasksDone+=1;
        cout<<"It is Analyst "<<analystNum<<" speaking and we have completed task number "<<tasksDone <<"\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_post(&GotCPU);
        cout<<"It is Analyst "<<analystNum<<" speaking and we released the cpu from the shackles\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_post(&TaskGo);
        sem_post(&GotMemory);
        cout<<"It is Analyst "<<analystNum<<" speaking and we released the memory from the shackles\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
    }

}
void* Analyst3(void*){
    int tasksDone =0;
    int analystNum =3;
    while(tasksDone<10){
        cout<<"It is Analyst "<<analystNum<<" speaking and we are about to start a task\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_wait(&GotMemory);
        cout<<"It is Analyst "<<analystNum<<" speaking and we have got 2 memory slots\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_wait(&GotCPU);
        cout<<"It is Analyst "<<analystNum<<" speaking and we have got a CPU FINALYYYYY\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_wait(&TaskGo);
        cout<<"It is Analyst "<<analystNum<<" speaking and we are about to start task number "<<tasksDone <<"\n";
        this_thread::sleep_for(chrono::milliseconds(300));tasksDone+=1;
        cout<<"It is Analyst "<<analystNum<<" speaking and we have completed task number "<<tasksDone <<"\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_post(&GotCPU);
        cout<<"It is Analyst "<<analystNum<<" speaking and we released the cpu from the shackles\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_post(&TaskGo);
        sem_post(&GotMemory);
        cout<<"It is Analyst "<<analystNum<<" speaking and we released the memory from the shackles\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
    }
}

int main(){
sem_init(&GotCPU, 0,CpuResource);
sem_init(&GotMemory, 0,MemoryResource);
sem_init(&TaskGo, 0,CpuResource);

    cout<<"                                     Show begins: \n\n\n";
    pthread_t analy1, analy2, analy3;
    
    if((pthread_create(&analy1, NULL, Analyst1, NULL))<0){ cout<<"Error in creating thread of analyst 1 so we gonna exit the process\n"; exit(-1);}
        if((pthread_create(&analy2, NULL, Analyst2, NULL))<0){ cout<<"Error in creating thread of analyst 2 so we gonna exit the process\n"; exit(-1);}
        if((pthread_create(&analy3, NULL, Analyst3, NULL))<0){ cout<<"Error in creating thread of analyst 3 so we gonna exit the process\n"; exit(-1);}

    pthread_join(analy1, NULL);
    pthread_join(analy2, NULL);
    pthread_join(analy3, NULL);
    selfKill();
}



