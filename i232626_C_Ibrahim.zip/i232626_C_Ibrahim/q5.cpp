#include <semaphore.h>
#include <mutex>
#include <thread>
#include <chrono>
#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>
#include <sys/wait.h>
#include <sys/wait.h>
#include <fcntl.h>
#include <pthread.h>
#include <signal.h>
#include <iostream>
#include <string>
#include <cstring>
#include <errno.h>
#include <sys/types.h>
using namespace std;
// this_thread::sleep_for(chrono::milliseconds(700));
// muti.lock()
// muti.unlock();
// sem_t S_A;
// sem_init(&S_A, 0, 1);
// sem_wait(&S_A);
// sem_post(&S_A);


// for logs, i will be printing it all on the terminal because i seriously dont remember th commands for  the file writingin cpp


#define CarsAmount 40
#define Direction (CarsAmount/4)
#define EmergencyVehicles 5
#define ReactionTime 100
sem_t North[2];
sem_t South[2];
sem_t West[2];
sem_t East[2];
sem_t emergency;
sem_t EndCall; 
int EndCallBBG =CarsAmount+EmergencyVehicles;
int charvehicles[2]={1,1};

void selfKill(){cout<<"I am going to kill myself :)\n";kill(getpid(), SIGKILL);}
unsigned long long int RandRand(long long int abc){abc = abc*23/67%46*(getpid())%31*3.1415926*abc*48659; return (abc>0?abc:(abc*-1));}
void* TravelCarNorth(void*){
        string hi = "cout<<No other Emergency vehicle in the intersection, so we are in;";
        int abc=RandRand((*(long long int*)&hi)); string directioniii = "North";
        int abc2=RandRand((*(long long int*)&hi)); string directionabc = ((abc2%4)>2?"Coming":"Going");
    cout<<"Car "<<charvehicles[0]<<":"<<" Waiting to see if any other car is in the intersection of "<<directioniii<<" and "<<directionabc<<" \n";
    if(directionabc=="Going"){
        sem_wait(&North[0]);
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"No other in the direction or lane, so we are in\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we are starting\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we are almosy ending our path\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_post(&North[0]);
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we have ended our path\n";
    }else{
        sem_wait(&North[1]);
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"No other in the direction or lane, so we are in\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we are starting\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we are almosy ending our path\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_post(&North[1]);
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we have ended our path\n";
    }
    // sem_post(&EndCallBBG);
    sem_wait(&EndCall);
    EndCallBBG--;
    charvehicles[0]+=1;
    sem_post(&EndCall);
}
void* TravelCarSouth(void*){
        string hi = "cout<<No other Emergency vehicle in the intersection, so we are in;";
        int abc=RandRand((*(long long int*)&hi)); string directioniii = "South";
        int abc2=RandRand((*(long long int*)&hi)); string directionabc = ((abc2%4)>2?"Coming":"Going");
    cout<<"Car "<<charvehicles[0]<<":"<<" Waiting to see if any other car is in the intersection of "<<directioniii<<" and "<<directionabc<<" \n";
    if(directionabc=="Going"){
        sem_wait(&South[0]);
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"No other in the direction or lane, so we are in\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we are starting\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we are almosy ending our path\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_post(&South[0]);
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we have ended our path\n";
    }else{
        sem_wait(&South[1]);
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"No other in the direction or lane, so we are in\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we are starting\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we are almosy ending our path\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_post(&South[1]);
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we have ended our path\n";
    }
    // sem_post(&EndCallBBG);
    sem_wait(&EndCall);
    EndCallBBG--;
    charvehicles[0]+=1;
    sem_post(&EndCall);
}
void* TravelCarWest(void*){
        string hi = "cout<<No other Emergency vehicle in the intersection, so we are in;";
        int abc=RandRand((*(long long int*)&hi)); string directioniii = "West";
        int abc2=RandRand((*(long long int*)&hi)); string directionabc = ((abc2%4)>2?"Coming":"Going");
    cout<<"Car "<<charvehicles[0]<<":"<<" Waiting to see if any other car is in the intersection of "<<directioniii<<" and "<<directionabc<<" \n";
    if(directionabc=="Going"){
        sem_wait(&West[0]);
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"No other in the direction or lane, so we are in\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we are starting\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we are almosy ending our path\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_post(&West[0]);
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we have ended our path\n";
    }else{
        sem_wait(&West[1]);
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"No other in the direction or lane, so we are in\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we are starting\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we are almosy ending our path\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_post(&West[1]);
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we have ended our path\n";
    }
    // sem_post(&EndCallBBG);
    sem_wait(&EndCall);
    EndCallBBG--;
    charvehicles[0]+=1;
    sem_post(&EndCall);
}
void* TravelCarEast(void*){
        string hi = "cout<<No other Emergency vehicle in the intersection, so we are in;";
        int abc=RandRand((*(long long int*)&hi)); string directioniii = "East";
        int abc2=RandRand((*(long long int*)&hi)); string directionabc = ((abc2%4)>2?"Coming":"Going");
    cout<<"Car "<<charvehicles[0]<<":"<<" Waiting to see if any other car is in the intersection of "<<directioniii<<" and "<<directionabc<<" \n";
    if(directionabc=="Going"){
        sem_wait(&East[0]);
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"No other in the direction or lane, so we are in\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we are starting\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we are almosy ending our path\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_post(&East[0]);
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we have ended our path\n";
    }else{
        sem_wait(&East[1]);
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"No other in the direction or lane, so we are in\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we are starting\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we are almosy ending our path\n";
        this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        sem_post(&East[1]);
            cout<<"Car "<<charvehicles[0]<<":"<<"Our diections is: "<<directioniii<<" and "<<directionabc<<" and we have ended our path\n";
    }
    // sem_post(&EndCallBBG);
    sem_wait(&EndCall);
    EndCallBBG--;
    charvehicles[0]+=1;
    sem_post(&EndCall);
}
// void enndEvrything(){ while()  kill(getpid(), SIGKILL);}
void* VehicleEmergency(void* ){
    cout<<"EmergenncyVehicle "<<charvehicles[1]<<":"<<"Emergency: Waiting to see if any other Emergency vehicle in the intersection\n";
    sem_wait(&emergency);
    this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        cout<<"EmergenncyVehicle "<<charvehicles[1]<<":"<<"No other Emergency vehicle in the intersection, so we are in\n";
    this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        string hi = "cout<<No other Emergency vehicle in the intersection, so we are in;";
    this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        int abc=RandRand((*(long long int*)&hi)); string directioniii = ((abc%4)>2?"North":((abc>1)?"South":((abc>0)?"East":"West")));
        int abc2=RandRand((*(long long int*)&hi)); string directionabc = ((abc2%4)>2?"Coming":"Going");
        cout<<"EmergenncyVehicle "<<charvehicles[1]<<":"<<"Emergency: Our diections is: "<<directioniii<<" and "<<directionabc<<" and we are starting\n";
    this_thread::sleep_for(chrono::milliseconds(ReactionTime));
        cout<<"EmergenncyVehicle "<<charvehicles[1]<<":"<<"Emergency: Our diections is: "<<directioniii<<" and "<<directionabc<<" and we are almosy ending our path\n";
    this_thread::sleep_for(chrono::milliseconds(ReactionTime));
    sem_post(&emergency);
        cout<<"EmergenncyVehicle "<<charvehicles[1]<<":"<<"Emergency: Our diections is: "<<directioniii<<" and "<<directionabc<<" and we have ended our path\n";
    // sem_post(&EndCallBBG);
    sem_wait(&EndCall);
    EndCallBBG--;
    charvehicles[1]+=1;
    sem_post(&EndCall);
}
int main(){
sem_init(&EndCall, 0,1);
sem_init(&North[0], 0,1);
sem_init(&North[1], 0,1);
sem_init(&South[0], 0,1);
sem_init(&South[1], 0,1);
sem_init(&West[0], 0,1);
sem_init(&West[1], 0,1);
sem_init(&East[0], 0,1);
sem_init(&East[1], 0,1);
sem_init(&emergency, 0,1);
    cout<<"                                     Show begins: \n\n\n";
    pthread_t Cars[CarsAmount];
    pthread_t Emnumi[EmergencyVehicles];

    for(int i=0;i<Direction;i++){
        if((pthread_create(&(Cars[i]), NULL, TravelCarNorth, NULL))<0){ cout<<"Error in creating thread of cars, thread number: "<<i<<" so we gonna exit the process\n"; exit(-1);}
    }
    for(int i=Direction;i<(Direction*2);i++){
        if((pthread_create(&(Cars[i]), NULL, TravelCarSouth, NULL))<0){ cout<<"Error in creating thread of cars, thread number: "<<i<<" so we gonna exit the process\n"; exit(-1);}
    }
    for(int i=(Direction*2);i<(Direction*3);i++){
        if((pthread_create(&(Cars[i]), NULL, TravelCarWest, NULL))<0){ cout<<"Error in creating thread of cars, thread number: "<<i<<" so we gonna exit the process\n"; exit(-1);}
    }
    for(int i=(Direction*3);i<CarsAmount;i++){
        if((pthread_create(&(Cars[i]), NULL, TravelCarEast, NULL))<0){ cout<<"Error in creating thread of cars, thread number: "<<i<<" so we gonna exit the process\n"; exit(-1);}
    }
    for(int i=0;i<EmergencyVehicles;i++){
        if((pthread_create(&(Emnumi[i]), NULL, TravelCarEast, NULL))<0){ cout<<"Error in creating thread of emergency vehicle, thread number: "<<i<<" so we gonna exit the process\n"; exit(-1);}
    }
    for(int i=0;i<CarsAmount;i++){pthread_join((Cars[i]), NULL);}
    for(int i=0;i<EmergencyVehicles;i++){pthread_join((Emnumi[i]), NULL);}
    selfKill();
}



